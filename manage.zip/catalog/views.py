from django.contrib import messages
from django.shortcuts import render, redirect
from accounts.decorators import manager_required
from .forms import CategoryForm, ProductForm
from .models import Category, Product

@manager_required
def category_list(request):
    return render(request, "catalog/category_list.html", {"categories": Category.objects.all()})

@manager_required
def category_create(request):
    form = CategoryForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        obj = form.save(commit=False)
        obj.created_by = request.user
        obj.save()
        messages.success(request, "Category created.")
        return redirect("catalog:categories")
    return render(request, "catalog/category_form.html", {"form": form, "heading": "Add category"})

@manager_required
def product_list(request):
    products = Product.objects.select_related("category").filter(is_active=True)
    query = request.GET.get("q", "").strip()
    if query:
        products = products.filter(name__icontains=query) | products.filter(sku__icontains=query)
    category_id = request.GET.get("category")
    if category_id:
        products = products.filter(category_id=category_id)
    return render(request, "catalog/product_list.html", {"products": products.distinct(), "categories": Category.objects.filter(is_active=True), "query": query})

@manager_required
def product_create(request):
    form = ProductForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save(user=request.user)
        messages.success(request, "Product created with opening stock.")
        return redirect("catalog:products")
    return render(request, "catalog/product_form.html", {"form": form, "heading": "Add product"})
